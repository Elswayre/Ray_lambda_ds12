class Polo():
    def __init__(self, style, size, color):
        self.style = style
        self.size = size
        self.color = color
        def pop_collar(self):
            print('popping coller')




if __name__ == '__main__':
    polo = Polo(style='sheek', size='L',color='Blue')
    print(type(polo))
    print(polo.size)
    print(polo.color)
    print(polo.size)


    polo2 = Polo(style='shimmer', size='s',color='yellow')
    print(type(polo))
    print(polo2.size)
    print(polo2.color)
    print(polo2.size)