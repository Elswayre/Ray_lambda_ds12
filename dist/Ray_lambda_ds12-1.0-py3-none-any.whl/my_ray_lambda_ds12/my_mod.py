# my_lambdata/my_mod.py
def enlarge(n):
    """
    Param n is a number
    Function will enlarge the number
    """
    return n * 100